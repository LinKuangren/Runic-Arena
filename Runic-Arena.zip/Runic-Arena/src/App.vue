<template>
  <main>
    <RouterView></RouterView>
  </main>
</template>

<script>
export default {};
</script>
